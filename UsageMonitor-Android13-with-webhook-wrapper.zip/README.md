# Usage Monitor

A visible Android 13+ usage-monitoring app for a parent-managed Android media player.

## Features

- Visible dashboard
- Android Usage Access permission flow
- Today's foreground usage by application
- Configurable Webhook.site endpoint
- Manual "Send Report Now"
- Automatic report every 3 hours with WorkManager
- Last successful report timestamp
- Does not capture screen contents, messages, keystrokes, passwords, microphone audio, or camera data

## Build

1. Open this directory in Android Studio.
2. Let Gradle sync.
3. Connect the Android 13+ media player or use an emulator.
4. Build > Build APK(s).
5. Install the generated APK.
6. Open Usage Monitor.
7. Tap "Open Usage Access Settings" and enable Usage Monitor.
8. Open "Webhook Settings" and paste your Webhook.site URL.
9. Tap "Send Report Now" to verify the endpoint.

## Important Android behavior

Android controls background execution. WorkManager's periodic work is not guaranteed to execute at exactly the three-hour mark; the operating system may defer it. The worker sends the report when the job is actually run and network constraints are satisfied.

The app intentionally uses the normal Usage Access mechanism rather than AccessibilityService or screen capture APIs.

## Report format

The webhook receives JSON similar to:

{
  "deviceModel": "Your Media Player",
  "reportedAt": "2026-10-01T19:00:00-04:00",
  "period": "today",
  "apps": [
    {
      "packageName": "com.example.app",
      "appName": "Example",
      "foregroundSeconds": 1200,
      "lastUsedEpochMs": 1760000000000
    }
  ]
}
