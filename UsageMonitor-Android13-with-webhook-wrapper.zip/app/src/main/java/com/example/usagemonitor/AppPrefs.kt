package com.example.usagemonitor

import android.content.Context

class AppPrefs(context: Context) {
    private val prefs = context.getSharedPreferences("settings", Context.MODE_PRIVATE)

    var webhookUrl: String
        get() = prefs.getString("webhookUrl", "https://webhook.site/492a94be-7378-46a0-9d2f-2a08a204fe3c") ?: ""
        set(value) = prefs.edit().putString("webhookUrl", value.trim()).apply()

    var lastReport: String?
        get() = prefs.getString("lastReport", null)
        set(value) = prefs.edit().putString("lastReport", value).apply()
}
