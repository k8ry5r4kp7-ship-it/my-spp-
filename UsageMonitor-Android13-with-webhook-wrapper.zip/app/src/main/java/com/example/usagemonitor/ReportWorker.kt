package com.example.usagemonitor

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.text.SimpleDateFormat
import java.util.*

@Serializable
data class ReportApp(
    val packageName: String,
    val appName: String,
    val foregroundSeconds: Long,
    val lastUsedEpochMs: Long
)

@Serializable
data class UsageReport(
    val deviceModel: String,
    val reportedAt: String,
    val period: String,
    val apps: List<ReportApp>
)

class ReportWorker(
    context: Context,
    params: WorkerParameters
) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        val prefs = AppPrefs(applicationContext)
        val url = prefs.webhookUrl

        if (url.isBlank()) return Result.failure()
        if (!UsageReader.hasUsageAccess(applicationContext)) return Result.failure()

        val apps = UsageReader.today(applicationContext).map {
            ReportApp(
                it.packageName,
                it.label,
                it.totalMs / 1000,
                it.lastUsed
            )
        }

        val timestamp = SimpleDateFormat(
            "yyyy-MM-dd'T'HH:mm:ssXXX",
            Locale.US
        ).format(Date())

        val report = UsageReport(
            android.os.Build.MODEL,
            timestamp,
            "today",
            apps
        )

        val body = Json.encodeToString(report)
            .toRequestBody("application/json; charset=utf-8".toMediaType())

        val request = Request.Builder()
            .url(url)
            .post(body)
            .build()

        return try {
            OkHttpClient().newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    prefs.lastReport = timestamp
                    Result.success()
                } else {
                    Result.retry()
                }
            }
        } catch (_: Exception) {
            Result.retry()
        }
    }
}
