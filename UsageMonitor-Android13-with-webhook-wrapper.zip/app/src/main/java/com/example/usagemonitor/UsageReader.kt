package com.example.usagemonitor

import android.app.AppOpsManager
import android.app.usage.UsageStatsManager
import android.content.Context
import android.os.Process
import java.util.Calendar

data class AppUsage(
    val packageName: String,
    val label: String,
    val totalMs: Long,
    val lastUsed: Long
)

object UsageReader {
    fun hasUsageAccess(context: Context): Boolean {
        val appOps = context.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = appOps.unsafeCheckOpNoThrow(
            AppOpsManager.OPSTR_GET_USAGE_STATS,
            Process.myUid(),
            context.packageName
        )
        return mode == AppOpsManager.MODE_ALLOWED
    }

    fun today(context: Context): List<AppUsage> {
        if (!hasUsageAccess(context)) return emptyList()

        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }

        val manager = context.getSystemService(Context.USAGE_STATS_SERVICE)
                as UsageStatsManager

        val stats = manager.queryUsageStats(
            UsageStatsManager.INTERVAL_DAILY,
            cal.timeInMillis,
            System.currentTimeMillis()
        )

        val pm = context.packageManager

        return stats
            .filter { it.totalTimeInForeground > 0 }
            .map {
                val label = try {
                    pm.getApplicationLabel(
                        pm.getApplicationInfo(it.packageName, 0)
                    ).toString()
                } catch (_: Exception) {
                    it.packageName
                }
                AppUsage(
                    it.packageName,
                    label,
                    it.totalTimeInForeground,
                    it.lastTimeUsed
                )
            }
            .sortedByDescending { it.totalMs }
    }
}
