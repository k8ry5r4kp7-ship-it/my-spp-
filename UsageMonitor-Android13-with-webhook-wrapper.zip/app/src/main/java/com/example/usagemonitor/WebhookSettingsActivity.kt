package com.example.usagemonitor

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class WebhookSettingsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val prefs = AppPrefs(this)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 32, 32, 32)
        }

        layout.addView(TextView(this).apply {
            text = "Webhook Settings"
            textSize = 28f
        })

        layout.addView(TextView(this).apply {
            text = "Enter your Webhook.site URL. Reports are sent every 3 hours when the device has network connectivity."
            textSize = 15f
            setPadding(0, 16, 0, 16)
        })

        val input = EditText(this).apply {
            hint = "https://webhook.site/your-id"
            setText(prefs.webhookUrl)
            inputType = android.text.InputType.TYPE_CLASS_TEXT or
                    android.text.InputType.TYPE_TEXT_VARIATION_URI
        }
        layout.addView(input)

        layout.addView(Button(this).apply {
            text = "Save"
            setOnClickListener {
                prefs.webhookUrl = input.text.toString()
                finish()
            }
        })

        layout.addView(TextView(this).apply {
            text = "Privacy: this app sends only the usage fields shown on the dashboard. It does not capture screen contents, messages, keystrokes, passwords, microphone audio, or camera data."
            textSize = 13f
            setPadding(0, 24, 0, 0)
        })

        setContentView(layout)
    }
}
