package com.example.usagemonitor

import android.app.AppOpsManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.work.*
import com.example.usagemonitor.databinding.ActivityMainBinding
import java.util.concurrent.TimeUnit

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private lateinit var prefs: AppPrefs

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        prefs = AppPrefs(this)

        binding.accessButton.setOnClickListener {
            startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
        }

        binding.sendButton.setOnClickListener {
            if (!UsageReader.hasUsageAccess(this)) {
                binding.statusText.text = "Grant Usage Access first."
                return@setOnClickListener
            }
            binding.statusText.text = "Sending report…"
            OneTimeWorkRequestBuilder<ReportWorker>().build().also {
                WorkManager.getInstance(this).enqueue(it)
            }
        }

        binding.settingsButton.setOnClickListener {
            startActivity(Intent(this, WebhookSettingsActivity::class.java))
        }

        scheduleReporting()
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun scheduleReporting() {
        val request = PeriodicWorkRequestBuilder<ReportWorker>(3, TimeUnit.HOURS)
            .setConstraints(
                Constraints.Builder()
                    .setRequiredNetworkType(NetworkType.CONNECTED)
                    .build()
            )
            .build()

        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
            "usage_report",
            ExistingPeriodicWorkPolicy.UPDATE,
            request
        )
    }

    private fun refresh() {
        val hasAccess = UsageReader.hasUsageAccess(this)
        binding.statusText.text =
            if (hasAccess) "Monitoring enabled • Usage Access granted"
            else "Monitoring is off • Usage Access required"

        val apps = UsageReader.today(this)
        val total = apps.sumOf { it.totalMs }
        binding.totalUsageText.text = formatDuration(total)
        binding.lastReportText.text =
            "Last report: ${prefs.lastReport ?: "Never"}"

        binding.appsContainer.removeAllViews()
        apps.sortedByDescending { it.totalMs }.take(30).forEach { app ->
            val row = TextView(this).apply {
                text = "${app.label}\n${formatDuration(app.totalMs)}"
                textSize = 16f
                setPadding(12, 14, 12, 14)
            }
            binding.appsContainer.addView(row)
        }
    }

    private fun formatDuration(ms: Long): String {
        val minutes = ms / 60_000
        return if (minutes < 60) "$minutes min"
        else "${minutes / 60}h ${minutes % 60}m"
    }
}
