@echo off
setlocal
set GRADLE_VERSION=8.9
set DIST=%USERPROFILE%\.gradle\wrapper\dists\gradle-%GRADLE_VERSION%-bin
set ZIP=%USERPROFILE%\.gradle\gradle-%GRADLE_VERSION%-bin.zip
if not exist "%DIST%\gradle-%GRADLE_VERSION%\bin\gradle.bat" (
  if not exist "%ZIP%" (
    echo Downloading Gradle %GRADLE_VERSION%...
    powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-WebRequest -Uri 'https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip' -OutFile '%ZIP%'"
  )
  if exist "%DIST%" rmdir /s /q "%DIST%"
  mkdir "%DIST%"
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -LiteralPath '%ZIP%' -DestinationPath '%DIST%' -Force"
)
call "%DIST%\gradle-%GRADLE_VERSION%\bin\gradle.bat" %*
endlocal
